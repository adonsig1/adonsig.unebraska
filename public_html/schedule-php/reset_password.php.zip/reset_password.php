<?php
	include 'common.php';
?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
	<head>
		<title>Email user ID and password</title>
		<link rel="stylesheet" type="text/css" href="css/main.css">
		<style type="text/css">
			label {
				float: left;
				width: 9em;
				text-align: right;
				margin-right: 0.5em;
				white-space: nowrap;
			}
			P.submit button {
				margin-left: 7.5em;
			}
			fieldset {
				width: 30em;
			}
		</style>
	</head>
	<body>
		<?php include 'std_header.php' ?>
		
		<?php
			$action_done = 0; 
			if ($_REQUEST["action"] == "reset_password") {
				db_connect();
				$login = mysqli_real_escape_string($newconn, $_REQUEST["login"]);
				$query = "SELECT * from instructors WHERE (id = '$login' OR email = '$login')";
				$rs = mysqli_query($newconn, $query);
				$num = mysqli_num_rows($rs);
				if ($num == 0) {
					$errm = "No users found matching this information. Please try again.";
				} else {
					$r = mysqli_fetch_assoc($rs);
					$id = $r["id"];
					$fn = $r["fn"];
					$email = $r["email"];
					if ($email) {
						reset_password($id, $fn, $email); // defined at bottom of page
						$action_done = 1;
					} else {
						$errm = 
							"No email registered for this user. Please provide your email
							on <a href='/$ROOT/register.php'>the registration page</a>.";
					}
				}
			}
			
			if ($action_done):
		?>
		
		<h1>Thank you</h1>
		
		<p>
			Your password has been reset and you user ID 
			and new password have been emailed to you.
			Press the button below to return to the main page.
		</p>
		
		<p>
			<?php make_button("OK", "tick.png", "window.location='/$ROOT/index.php'") ?>
		</p>
		
		<?php 
			else:
		?>
		
		<?php
			if ($errm) {
				echo "<div class='errm'>$errm</div>";
			}
		?>
		<form action="reset_password.php" method="post" name="login_form">
			<fieldset>
				<legend>Email me my user ID and password</legend>
				<p>
					This form will reset your password and email it to you.
					Please enter your email address or user ID.
				</p>
				<p>
					If you don't remember the email address
					registered for your account, please email the vice chair
					and ask for it.
					In most cases your user ID is the first initial
					of your first name folowed by the first three
					letters of your last name (e.g., adon).
				</p>
				<p>
					<label for="login">User ID or email:</label> 
					<input type="text" name="login" id="login" value="<?php echo $login ?>">
					<input type="hidden" name="action" value="reset_password">
				</p>
				<p class="submit">
					<?php make_button("OK", "tick.png", "document.login_form.submit()") ?>
				</p>
			</fieldset>
		</form>
		<?php 
			endif;
		?>
		<?php include 'std_footer.php' ?>
	</body>
</html>
<?php
	function reset_password($id, $fn, $email) {
		global $ROOT,$newconn;
		$passwd = generatePassword();
		
		$update = "UPDATE instructors SET passwd = MD5('$passwd') WHERE id = '$id'";
		mysqli_query($newconn, $update) or die(mysqli_error());
		
		$message = <<<MAIL
Dear $fn,
		
This email is being sent because you requested a
reminder of your user ID and password on the UNL 
Math Department teaching preferences site.

Your password has been reset.

User ID: $id
Password: $passwd

Please visit http://www.math.unl.edu/$ROOT/
and log in with this ID and password.

Thanks!
		
MAIL;
		mail(
			$email, 
			"Teaching preferences: User ID and password",
			$message,
			"Reply-To: adonsig1@math.unl.edu"
		);
	}
?>
